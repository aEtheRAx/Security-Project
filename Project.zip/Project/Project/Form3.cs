﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
		//Global variables
		public string notes;
		Form1 mainForm = new Form1();

		private void rbEncrypt_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbDecrypt_CheckedChanged(object sender, EventArgs e)
        {

		}

        private void btnRun_Click(object sender, EventArgs e)
        {
			if (notes == "Vernam")
            {
				//Vernam algorithm is selected for application
				if (this.rbEncrypt.Checked == true)
                {
					VernamEncrypt();
                }
				else
                {
					VernamDecrypt();
                }
            }
			else if (notes == "Vignere")
			{
				//Vigenere algorithm is selected for application
				if (this.rbEncrypt.Checked == true)
				{
					textBoxOutput.Text = VigenereEncipher(textBoxInput.Text, textBoxKey.Text);
				}
				else
				{
					textBoxOutput.Text = VigenereDecipher(textBoxInput.Text, textBoxKey.Text);
				}
			}
			else if (notes == "Transposition Cipher")
			{
				//Transposition Cipher algorithm is selected for application
				string text = textBoxInput.Text;
				string key = textBoxKey.Text;
				char padChar, tmp;

				//Check to see if padding char is of char. If not, make '-' the padding char
				if (char.TryParse(textBoxPadding.Text, out tmp))
					padChar = tmp;
				else
				{
					padChar = '-';
				}
				//Encrypt and Decrypt
				if (this.rbEncrypt.Checked == true)
				{
					textBoxOutput.Text = TranspositionEncipher(text, key, padChar);
				}
				else
				{
					textBoxOutput.Text = TranspositionDecipher(text, key);
				}
			}
			else if (notes == "Custom")
			{
				//Own writen algorithm is selected for application
				if (this.rbEncrypt.Checked == true)
				{
					
				}
				else
				{
					
				}
			}

		}

		//Vernam Cipher - Start
		public void VernamEncrypt()
		{
			string plainText = textBoxInput.Text;
			string key = textBoxKey.Text;
			int result = 0;
			string vernam = "";

			if (key.Length < plainText.Length)
			{
				int l = key.Length;
				for (int k = key.Length; k < plainText.Length; k++)
				{
					key = key + key[k - l];
				}
			}

			for (int i = 0; i < plainText.Length; i++)
			{
				if (plainText[i] == ' ')
				{
					vernam = vernam + ' ';
				}
				else
				{
					result = plainText[i] ^ key[i];
					vernam = vernam + Convert.ToChar(result);
				}
			}
			textBoxOutput.Text = vernam;
		}

		public void VernamDecrypt()
		{
			string cipher = textBoxInput.Text;
			string key = textBoxKey.Text;

			int result = 0;
			string vernam = "";

			if (key.Length < cipher.Length)
			{
				int l = key.Length;
				for (int k = key.Length; k < cipher.Length; k++)
				{
					key = key + key[k - l];
				}
			}

			for (int i = 0; i < cipher.Length; i++)
			{
				if (cipher[i] == ' ')
				{
					vernam = vernam + ' ';

				}
				else
				{
					result = cipher[i] ^ key[i];
					vernam = vernam + Convert.ToChar(result);
				}

			}
			textBoxOutput.Text = vernam;
		}

		///Columnar transposition cipher - Start
		private static int[] GetShiftIndexes(string key)
		{
			int keyLength = key.Length;
			int[] indexes = new int[keyLength];
			List<KeyValuePair<int, char>> sortedKey = new List<KeyValuePair<int, char>>();
			int i;

			for (i = 0; i < keyLength; ++i)
				sortedKey.Add(new KeyValuePair<int, char>(i, key[i]));

			sortedKey.Sort(
				delegate (KeyValuePair<int, char> pair1, KeyValuePair<int, char> pair2) {
					return pair1.Value.CompareTo(pair2.Value);
				}
			);

			for (i = 0; i < keyLength; ++i)
				indexes[sortedKey[i].Key] = i;

			return indexes;
		}

		///Columnar transposition cipher ENCRYPT
		public static string TranspositionEncipher(string input, string key, char padChar)
		{
			input = (input.Length % key.Length == 0) ? input : input.PadRight(input.Length - (input.Length % key.Length) + key.Length, padChar);
			StringBuilder output = new StringBuilder();
			int totalChars = input.Length;
			int totalColumns = key.Length;
			int totalRows = (int)Math.Ceiling((double)totalChars / totalColumns);
			char[,] rowChars = new char[totalRows, totalColumns];
			char[,] colChars = new char[totalColumns, totalRows];
			char[,] sortedColChars = new char[totalColumns, totalRows];
			int currentRow, currentColumn, i, j;
			int[] shiftIndexes = GetShiftIndexes(key);

			for (i = 0; i < totalChars; ++i)
			{
				currentRow = i / totalColumns;
				currentColumn = i % totalColumns;
				rowChars[currentRow, currentColumn] = input[i];
			}

			for (i = 0; i < totalRows; ++i)
				for (j = 0; j < totalColumns; ++j)
					colChars[j, i] = rowChars[i, j];

			for (i = 0; i < totalColumns; ++i)
				for (j = 0; j < totalRows; ++j)
					sortedColChars[shiftIndexes[i], j] = colChars[i, j];

			for (i = 0; i < totalChars; ++i)
			{
				currentRow = i / totalRows;
				currentColumn = i % totalRows;
				output.Append(sortedColChars[currentRow, currentColumn]);
			}

			return output.ToString();
		}

		///Columnar transposition cipher DECRYPT
		public static string TranspositionDecipher(string input, string key)
		{
			StringBuilder output = new StringBuilder();
			int totalChars = input.Length;
			int totalColumns = (int)Math.Ceiling((double)totalChars / key.Length);
			int totalRows = key.Length;
			char[,] rowChars = new char[totalRows, totalColumns];
			char[,] colChars = new char[totalColumns, totalRows];
			char[,] unsortedColChars = new char[totalColumns, totalRows];
			int currentRow, currentColumn, i, j;
			int[] shiftIndexes = GetShiftIndexes(key);

			for (i = 0; i < totalChars; ++i)
			{
				currentRow = i / totalColumns;
				currentColumn = i % totalColumns;
				rowChars[currentRow, currentColumn] = input[i];
			}

			for (i = 0; i < totalRows; ++i)
				for (j = 0; j < totalColumns; ++j)
					colChars[j, i] = rowChars[i, j];

			for (i = 0; i < totalColumns; ++i)
				for (j = 0; j < totalRows; ++j)
					unsortedColChars[i, j] = colChars[i, shiftIndexes[j]];

			for (i = 0; i < totalChars; ++i)
			{
				currentRow = i / totalRows;
				currentColumn = i % totalRows;
				output.Append(unsortedColChars[currentRow, currentColumn]);
			}

			return output.ToString();
		}

		//Vigenere Cipher - Start
		///Mod function
		private static int Mod(int a, int b)
		{
			return (a % b + b) % b;
		}

		///Vigenere Cipher CORE FUNCTION
		private static string VigenereCipher(string input, string key, bool encipher)
		{
			for (int i = 0; i < key.Length; ++i)
				if (!char.IsLetter(key[i]))
                {
					MessageBox.Show("Key must be non-numeric");
					return null; // Error
				}

			string output = string.Empty;
			int nonAlphaCharCount = 0;

			for (int i = 0; i < input.Length; ++i)
			{
				if (char.IsLetter(input[i]))
				{
					bool cIsUpper = char.IsUpper(input[i]);
					char offset = cIsUpper ? 'A' : 'a';
					int keyIndex = (i - nonAlphaCharCount) % key.Length;
					int k = (cIsUpper ? char.ToUpper(key[keyIndex]) : char.ToLower(key[keyIndex])) - offset;
					k = encipher ? k : -k;
					char ch = (char)((Mod(((input[i] + k) - offset), 26)) + offset);
					output += ch;
				}
				else
				{
					output += input[i];
					++nonAlphaCharCount;
				}
			}
			return output;
		}

		///Vigenere Cipher ENCRYPT
		public static string VigenereEncipher(string input, string key)
		{
			return VigenereCipher(input, key, true);
		}

		///Vigenere Cipher DECRYPT
		public static string VigenereDecipher(string input, string key)
		{
			return VigenereCipher(input, key, false);
		}

        private void btnReturn_Click(object sender, EventArgs e)
        {
			mainForm.ShowDialog();
			this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
			if (mainForm.rbEncrypt.Checked == true)
			{
				rbEncrypt.Checked = true;
			}
			else
			{
				rbDecrypt.Checked = true;
			}
		}
    }
}
