﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Added libraries
using System.IO;


namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        //Global variables
        public string notes;
        byte[] abc;
        byte[,] table;
        /// <summary>
        /// abc is an alphabet, it contains all characters used to encrypt or decrypt.
        /// table is a matrix in 2D. Each row of table is all character from abc with row i begin with value in index i of abc:
        /// </summary>

        //Gets the file path and insert it into the text boxt
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog od = new OpenFileDialog();
            od.Multiselect = false;
            if (od.ShowDialog() == DialogResult.OK)
            {
                txtFilePath.Text = od.FileName;
            }
        }

        private void rbEncrypt_CheckedChanged(object sender, EventArgs e)
        {
            if (rbEncrypt.Checked)
            {
                rbDecrypt.Checked = false;
            }
        }

        private void rbDecrypt_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDecrypt.Checked)
            {
                rbEncrypt.Checked = false;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            rbEncrypt.Checked = true;

            // initialize the abc and table variables
            abc = new byte[256];
            for (int i = 0; i < 256; i++)
                abc[i] = Convert.ToByte(i);

            table = new byte[256, 256];
            for (int i = 0; i < 256; i++)
                for (int j = 0; j < 256; j++)
                {
                    table[i, j] = abc[(i + j) % 256];
                }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // Check input values
            if (!File.Exists(txtFilePath.Text))
            {
                MessageBox.Show("File does not exist.");
                return;
            }
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Password empty. Please enter your password");
                return;
            }

            if (notes == "Vigenere")
            {
                // Get file content and key for encrypt/decrypt
                try
                {
                    byte[] fileContent = File.ReadAllBytes(txtFilePath.Text);
                    byte[] passwordTmp = Encoding.ASCII.GetBytes(txtPassword.Text);
                    byte[] keys = new byte[fileContent.Length];

                    for (int i = 0; i < fileContent.Length; i++)
                        keys[i] = passwordTmp[i % passwordTmp.Length];
                    // Encrypt
                    byte[] result = new byte[fileContent.Length];
                    int nonAlphaCharCount = 0;
                    bool encipher;
                    if (rbEncrypt.Checked)
                    {
                        encipher = true;
                        for (int i = 0; i < fileContent.Length; ++i)
                        {
                            if (char.IsLetter(Convert.ToChar(fileContent[i])))
                            {
                                bool cIsUpper = char.IsUpper(Convert.ToChar(fileContent[i]));
                                char offset = cIsUpper ? 'A' : 'a';
                                int keyIndex = (i - nonAlphaCharCount) % keys.Length;
                                int k = (cIsUpper ? char.ToUpper(Convert.ToChar(fileContent[keyIndex])) : char.ToLower(Convert.ToChar(keys[keyIndex]))) - offset;
                                k = encipher ? k : -k;
                                char ch = (char)((Mod(((fileContent[i] + k) - offset), 26)) + offset);
                                result[i] = Convert.ToByte(ch);
                            }
                            else
                            {
                                result[i] = fileContent[i];
                                ++nonAlphaCharCount;
                            }
                        }
                    }
                    else
                    {
                        encipher = false;
                        for (int i = 0; i < fileContent.Length; ++i)
                        {
                            if (char.IsLetter(Convert.ToChar(fileContent[i])))
                            {
                                bool cIsUpper = char.IsUpper(Convert.ToChar(fileContent[i]));
                                char offset = cIsUpper ? 'A' : 'a';
                                int keyIndex = (i - nonAlphaCharCount) % keys.Length;
                                int k = (cIsUpper ? char.ToUpper(Convert.ToChar(fileContent[keyIndex])) : char.ToLower(Convert.ToChar(keys[keyIndex]))) - offset;
                                k = encipher ? k : -k;
                                char ch = (char)((Mod(((fileContent[i] + k) - offset), 26)) + offset);
                                result[i] = Convert.ToByte(ch);
                            }
                            else
                            {
                                result[i] = fileContent[i];
                                ++nonAlphaCharCount;
                            }
                        }
                    }
                    // Save result to new file with the same extension
                    String fileExt = Path.GetExtension(txtFilePath.Text);
                    SaveFileDialog sd = new SaveFileDialog();
                    sd.Filter = "Files (*" + fileExt + ") | *" + fileExt;
                    if (sd.ShowDialog() == DialogResult.OK)
                    {
                        File.WriteAllBytes(sd.FileName, result);
                    }
                }
                catch
                {
                    MessageBox.Show("File is in use. Close other program is using this file and try again.");
                    return;
                }
            }
            else if (notes == "Vernam")
            {
                // Get file content and key for encrypt/decrypt
                try
                {
                    byte[] fileContent = File.ReadAllBytes(txtFilePath.Text);
                    byte[] passwordTmp = Encoding.ASCII.GetBytes(txtPassword.Text);
                    byte[] keys = new byte[fileContent.Length];
                    for (int i = 0; i < fileContent.Length; i++)
                        keys[i] = passwordTmp[i % passwordTmp.Length];

                    // Encrypt
                    byte[] result = new byte[fileContent.Length];

                    if (rbEncrypt.Checked)
                    {
                        for (int i = 0; i < fileContent.Length; i++)
                        {
                            byte value = fileContent[i];
                            byte key = keys[i];
                            int valueIndex = -1, keyIndex = -1;
                            for (int j = 0; j < 256; j++)
                                if (abc[j] == value)
                                {
                                    valueIndex = j;
                                    break;
                                }
                            for (int j = 0; j < 256; j++)
                                if (abc[j] == key)
                                {
                                    keyIndex = j;
                                    break;
                                }
                            result[i] = table[keyIndex, valueIndex];
                        }
                    }
                    // Decrypt
                    else
                    {
                        for (int i = 0; i < fileContent.Length; i++)
                        {
                            byte value = fileContent[i];
                            byte key = keys[i];
                            int valueIndex = -1, keyIndex = -1;
                            for (int j = 0; j < 256; j++)
                                if (abc[j] == key)
                                {
                                    keyIndex = j;
                                    break;
                                }
                            for (int j = 0; j < 256; j++)
                                if (table[keyIndex, j] == value)
                                {
                                    valueIndex = j;
                                    break;
                                }
                            result[i] = abc[valueIndex];
                        }
                    }

                    // Save result to new file with the same extension
                    String fileExt = Path.GetExtension(txtFilePath.Text);
                    SaveFileDialog sd = new SaveFileDialog();
                    sd.Filter = "Files (*" + fileExt + ") | *" + fileExt;
                    if (sd.ShowDialog() == DialogResult.OK)
                    {
                        File.WriteAllBytes(sd.FileName, result);
                    }
                }
                catch
                {
                    MessageBox.Show("File is in use. Close other program is using this file and try again.");
                    return;
                }
            }
        }

        //Vigenere Cipher - Mod function
        private static int Mod(int a, int b)
        {
            return (a % b + b) % b;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.ShowDialog();
            this.Close();
        }
    }
}
