﻿using System;
using System.Windows.Forms;
//Added libraries

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string algo;

        private void Form1_Load(object sender, EventArgs e)
        {
        }


        private void btnFiles_Click(object sender, EventArgs e)
        {
            Form2 FileEncryptionForm = new Form2();
            FileEncryptionForm.notes = cmbAlgorithm.Text;
            FileEncryptionForm.ShowDialog();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnText_Click(object sender, EventArgs e)
        {
            Form3 TextEncryptionForm = new Form3();
            TextEncryptionForm.notes = cmbAlgorithm.Text;
            TextEncryptionForm.ShowDialog();
        }

        private void cmbAlgorithm_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAlgorithm.Text == "Transposition Cipher")
            {
                cbPaddingCharacter.Checked = true;
                cbKey.Checked = true;
            }
            else if (cmbAlgorithm.Text == "Vernam")
            {
                cbPaddingCharacter.Checked = false;
                cbKey.Checked = true;
            }
            else if (cmbAlgorithm.Text == "Vignere")
            {
                cbPaddingCharacter.Checked = false;
                cbKey.Checked = true;
            }
        }
    }
}
